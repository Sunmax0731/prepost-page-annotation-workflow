あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: ChromeExtension
- No.: 4
- 分野: 投稿・ページ作業品質
- アイデア: 投稿前チェック・ページ注釈ワークフロー
- リポジトリ名: prepost-page-annotation-workflow

## 元アイデア

- 概要: フォーム入力、投稿文、SNS滞在、NGワード、サイト別チェックリスト、ページ注釈をまとめて扱う。
- 課題: 同じサイトでの投稿や確認作業が記憶頼りになり、入力漏れや品質確認漏れが出やすい。
- 類似サービス・アプリ: Grammarly, Notion Web Clipper, Todoist, browser extensions
- 差別化ポイント: URLごとの手順と投稿前チェックをページ上に重ねて表示する。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
