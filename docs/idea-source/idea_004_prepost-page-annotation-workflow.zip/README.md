# 投稿前チェック・ページ注釈ワークフロー 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ChromeExtension |
| No. | 4 |
| 分野 | 投稿・ページ作業品質 |
| アイデア | 投稿前チェック・ページ注釈ワークフロー |
| リポジトリ名 | prepost-page-annotation-workflow |
| 概要 | フォーム入力、投稿文、SNS滞在、NGワード、サイト別チェックリスト、ページ注釈をまとめて扱う。 |
| 課題 | 同じサイトでの投稿や確認作業が記憶頼りになり、入力漏れや品質確認漏れが出やすい。 |
| 類似サービス・アプリ | Grammarly, Notion Web Clipper, Todoist, browser extensions |
| 差別化ポイント | URLごとの手順と投稿前チェックをページ上に重ねて表示する。 |

## 目的

このZIPには、`ChromeExtension` 領域のアイデア `投稿前チェック・ページ注釈ワークフロー` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
